from __future__ import division

"""
Emily Newman's TP F15

Using Pygame and PyEphem libraries
"""
import pygame
from framework import Framework 
import ephem
import ephem.stars
import datetime, time
import math

# class Star(object):
#     def __init__(self)


class Planetarium(Framework):
    def __init__(self, width=600, height=400, fps=50, title="PGH Planetarium"):
        super(Planetarium, self).__init__()
        self.title = "PGH Planetarium"
        self.bgColor = self.BLACK
        self.font = pygame.font.SysFont("monospace", 12)
        self.shift = 200 #changes with zooming?
        #full screen width and height
        self.fullWidth = self.shift*2
        self.fullHeight = self.shift*2
        self.log = dict() #stores all stars based on computed values WRT PGH
        self.pos = dict() #stores all screen positions of stars
        (self.MIN_ALT, self.MAX_ALT) = (0, math.pi/2)
        (self.MIN_AZ, self.MAX_AZ) = (0, 2*math.pi) #radians
        # upper left corner of screen in terms of sky
        # starts w/ center of screen being (0,0) of sky
        self.screenPos = (self.shift-self.width//2, self.shift-self.height//2)
        self.starR = 2
        self.date = datetime.datetime.now() #always Datetime form
        self.initPittsburgh()
        self.calculateStars()
        
        self.inRealTime = False

    def initPittsburgh(self):
        self.pgh = ephem.Observer()
        self.pgh.lat = "40:26:26.3"
        self.pgh.long = "-79:59:45.20" 
        self.pgh.date = ephem.Date(self.date)
        self.pgh.epoch = self.pgh.date

    def calculateStars(self):
        count = 0
        for star in ephem.stars.db.split("\n"):
            starName = star.split(",")[0]
            if starName == "": continue #not a star
            self.log[starName] = ephem.star(starName)
            self.log[starName].compute(self.pgh)
            if self.log[starName].alt < 0: #below horizon
                self.pos[starName] = None
                continue
            phi = self.log[starName].alt + math.pi/2
            theta = 2*math.pi - self.log[starName].az
            #convert from spherical to cartesian xy coordinates
            #constant sphere radius
            x = math.sin(phi)*math.cos(theta)
            y = math.sin(phi)*math.sin(theta)
            #convert to draw-able coordinates
            #stores them based on "big" screen, not "current" screen
            self.pos[starName] = (self.shift * (x + 1), self.shift * (-y + 1))
            count += 1



    def init(self):
        pass

    def mousePressed(self, x, y):
        pass

    def mouseReleased(self, x, y):
        pass

    def mouseMotion(self, x, y):
        pass

    def mouseDrag(self, x, y):
        pass

    def keyPressed(self, keyCode, modifier):
        pass

    def keyReleased(self, keyCode, modifier):
        pass

    def timerFired(self, dt):
        #self.inRealTime = True
        if self.inRealTime == True:
            self.date = datetime.datetime.now()
        else: #for testing
            newMinute = self.date.minute+1
            newHour = self.date.hour
            if self.date.minute+1 >= 60: 
                newMinute = (self.date.minute+1)%60
                newHour = self.date.hour+1
            self.date = self.date.replace(self.date.year, self.date.month, 
                                    self.date.day, newHour%24, newMinute)
        self.updatePgh()
        self.calculateStars()

    def updatePgh(self):
        self.pgh.date = ephem.Date(self.date)
        self.pgh.epoch = self.pgh.date

    def redrawAll(self, screen):
        self.drawStars(screen)

    def drawStars(self, screen):
        #count = 0
        for star in self.pos:
            if self.pos[star] != None: #star is above horizon
                (x, y) = self.pos[star] 
                #convert "big screen" coords to "current screen" coords
                (screenLeft, screenUp) = self.screenPos
                x = int(x - screenLeft)
                y = int(y - screenUp)
                if self.pointInBox(x, y, (0, 0, self.width, self.height)):
                    point = (x, y)
                    pygame.draw.circle(screen, self.WHITE, point, self.starR)
                    label = self.font.render(star, 1, self.GREEN)
                    screen.blit(label, (x, y))
                #count += 1

        #print count


    def isKeyPressed(self, key):
        # return whether a specific key is being held 
        return self._keys.get(key, False)


    @staticmethod
    def pointInBox(x, y, boxCoords): #from my hw8a.py
        (boxLeft, boxTop, boxRight, boxBot) = boxCoords
        return boxLeft<=x<=boxRight and boxTop<=y<=boxBot 

Planetarium().run()